package com.gongganmutual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GongganmutualApplicationTests {

	@Test
	void contextLoads() {
	}

}
